import HotelFile
from random import randint

class Game(object):

    game_hotel = None
    Strike_Counter = 0

    def __init__(self, hotel):
        self.game_hotel = hotel

#Prints out everything.
    def message(self):
        print "Game's difficulty: " + self.game_hotel.difficulty
        print "The player's name: " + self.game_hotel.player_name
        print "Strikes (3 Strikes = game over): " + str(self.Strike_Counter)
        print "Score: " + str(self.game_hotel.Score)
        for x in range(len(self.game_hotel.rooms)):
            print "Room #" + str(x+1)

#---------
#Game loop
#---------
    def game_loop(self):
        self.guest_gets_a_room()
        #self.guest_enters_room()
        print "3 strikes! Game Over!"
#-------------
#Game loop end
#-------------

#lets the user pick a room
    def choose_room_to_clean(self):
        self.choice = int(raw_input("Press a button (1-4) to clean. 5 to wait"))
        #self.choice = int(self.choice)
        if self.choice >= 1 and self.choice <= 4:
            self.game_hotel.rooms[self.choice-1].clean_room()
        else:
            print "Waiting for orders..."

#Guest gets assigned an empty room.
    def guest_gets_a_room(self):
        while (self.Strike_Counter < len(self.game_hotel.rooms)):
            print "-"*10
            print "Strikes so far: ", str(self.Strike_Counter)
            for x in range (0, len(self.game_hotel.rooms)+1):
                if x < len(self.game_hotel.rooms):
                    if self.game_hotel.rooms[x].has_guest == False:
                        self.game_hotel.rooms[x].guest_enter()
                        break
                else:
                    print "No available rooms at this moment..."
            self.choose_room_to_clean()

#Guest enters room
#Increases the strike counter with 1 if the room is dirty
    def guest_enters_room(self):
        self.Strike_Counter = self.game_hotel.rooms[
            randint(0, len(self.game_hotel.rooms)-1)].guest_visit(self.Strike_Counter)

#save game
    def save_game(self):
        try:
            game_hotel.write_to_file()
        except:
            print "No save file."

#save information to save.txt
    def write_to_file(self):
        print "Writing to save.txt..."
        print "Player name: " + self.game_hotel.player_name
        print "Difficulty: " + self.game_hotel.difficulty
        self.save_file = open("save.txt", "w")
        sentence = str(self.game_hotel.difficulty) + "\n"
        sentence += str(self.game_hotel.player_name) + "\n"
        sentence += str(self.game_hotel.Score) + "\n"
        sentence += str(self.Strike_Counter) + "\n"
        self.save_file.write(sentence)
