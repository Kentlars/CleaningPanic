#to keep track on rooms
from random import randint
from random import getrandbits

class Room(object):

    is_cleaned = True
    has_guest = False
    room_number = 0

    def __init__(self, number):
        self.is_cleaned = True
        self.has_guest = False
        self.room_number = number

#Adds a strike point if the room is dirty when the guest is visiting it
    def guest_visit(self, strike_point):
        print "Calling room " , self.room_number
        if self.is_cleaned == False:
            print "Room %s is dirty! Increasing strike point by 1!" % self.room_number
            strike_point += 1
            self.is_cleaned = True
            print "Room %s is now clean" % self.room_number
        return strike_point

#guest enters the room
    def guest_enter(self):
        print "Guest has entered room #%s." % self.room_number
        self.has_guest = True

#makes the room dirty after guest leaves the room
    def guest_leave(self):
        #if bool(getrandbits(1)) == True:
            print "Guest has left the room #%s, leaving it dirty..." % self.room_number
            self.has_guest = False
            self.is_cleaned = False

#cleans the room if there's no one inside of it
    def clean_room(self):
        if self.has_guest == True:
            print "There's a guest in room #%s! Please do not disturb our guests" % self.room_number
        else:
            print "Cleaning room #%s" % self.room_number
