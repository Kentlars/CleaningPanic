class Hotel(object):

    @classmethod
    def from_difficulty(cls, difficulty):
        obj = cls()
        obj.difficulty = difficulty
        obj.player_name = ""
        return obj

#When a player choses 3 as startup-argument, it uses a constructor to load in
#existing values from "save.txt"
    @classmethod
    def from_everything(cls):
        obj = cls()
        file = open("save.txt")
        lines = file.read().splitlines()
        obj.difficulty = lines[0]
        obj.player_name = lines[1]
        return obj

    def setup_player(self):
        #problem with input,  use raw_input
        self.player_name = raw_input('What is your name?')
        print "Hello", self.player_name, "!"

    def write_to_file(self):
        self.save_file = open("save.txt", "w")
        sentence = str(self.difficulty) + "\n"
        sentence += str(self.player_name)
        self.save_file.write(sentence)
