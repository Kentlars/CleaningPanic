import Room

class Hotel(object):

    Score = 0
    Strike_Counter = 0

#default constructor
    @classmethod
    def from_start(cls, difficulty):
        obj = cls()
        obj.difficulty = difficulty
        obj.player_name = ""
        obj.setup_player()
        obj.write_to_file()
        return obj

#When a player choses 3 as startup-argument, it uses a constructor to load in
#existing values from "save.txt"
    @classmethod
    def from_everything(cls):
        obj = cls()
        file = open("save.txt")
        lines = file.read().splitlines()
        obj.difficulty = lines[0]
        obj.player_name = lines[1]
        obj.Score = lines[2]
        return obj

    def setup_player(self):
        self.player_name = raw_input('What is your name? ')
        print "Hello", self.player_name, "!"

#save information to save.txt
    def write_to_file(self):
        print "Writing to save.txt..."
        print "Player name: " + self.player_name
        print "Difficulty: " + self.difficulty
        self.save_file = open("save.txt", "w")
        sentence = str(self.difficulty) + "\n"
        sentence += str(self.player_name) + "\n"
        sentence += str(self.Score)
        self.save_file.write(sentence)
