#!/usr/bin/python

import sys
import HotelClass
import Game

print "Work in progress..."

#setting up game, then saves
def game_start(game_difficulty):
    hotel = HotelClass.Hotel.from_start(game_difficulty)
    print "Test game_start"
    game = Game.Game(hotel)
    game.message()

#checking what sys.argv[1] is
try:
    if int(sys.argv[1]) == 1 or int(sys.argv[1]) == 2 or int(sys.argv[1]) != 3:
        if int(sys.argv[1]) == 1:
            print "Selecting normal difficulty."
        if int(sys.argv[1]) == 2:
            print "Selecting hard difficulty."
        if int(sys.argv[1]) > 3 or int(sys.argv[1]) < 1:
            print "Higher value than 2 detected, defaulting to normal difficulty."
            sys.argv[1] = 1
        game_start(sys.argv[1])
    #Picking up from previous save file
    if int(sys.argv[1]) == 3:
        print "Picking up from previous save file..."
        hotel = HotelClass.Hotel.from_everything()
except ValueError:
    print "No valid value was given, (1 or 2 for difficulty, 3 for continuing). Exiting..."
    exit()

#Debug silliness, please help
#print hotel.player_name
#print hotel.difficulty
#print hotel.Score
