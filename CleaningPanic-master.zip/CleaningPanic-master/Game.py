import HotelClass

class Game(object):

    game_hotel = None

    def __init__(self, hotel):
        self.game_hotel = hotel

#Prints out everything.
    def message(self):
        print "Game's difficulty: " + self.game_hotel.difficulty
        print "The player's name: " + self.game_hotel.player_name
        print "Strikes (3 Strikes = game over): " + str(self.game_hotel.Strike_Counter)
        print "Score: " + str(self.game_hotel.Score)

#save game
    def save_game(self):
        try:
            game_hotel.write_to_file()
        except:
            print "No save file."
