#to keep track on rooms
class Room(object):

    is_cleaned = None
    has_guest = None
    room_number = 0

    def __init__(self, room_number):
        self.is_cleaned = True
        self.room_number = room_number
        self.has_guest = False

    def guest_visit(self, strike_point):
        self.has_guest = True
        if is_cleaned == True:
            strike_point += 1
        return strike_point

    def guest_leave(self):
        self.has_guest = False
        is_cleaned = False
