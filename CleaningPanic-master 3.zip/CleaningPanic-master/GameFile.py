import HotelFile
from random import randint

class Game(object):

    game_hotel = None
    Strike_Counter = 0

    def __init__(self, hotel):
        self.game_hotel = hotel

#Prints out everything.
    def message(self):
        print "Game's difficulty: " + self.game_hotel.difficulty
        print "The player's name: " + self.game_hotel.player_name
        print "Strikes (3 Strikes = game over): " + str(self.Strike_Counter)
        print "Score: " + str(self.game_hotel.Score)
        for x in range(len(self.game_hotel.rooms)):
            print "Room #" + str(x+1)
#Game
    def game_loop(self):
        while (self.Strike_Counter < 3):
            print "Strikes so far: ", str(self.Strike_Counter)
            raw_input("Press a button")
            #Increases the strike counter with 1 if the room is dirty
            self.Strike_Counter = self.game_hotel.rooms[
                randint(0, len(self.game_hotel.rooms)-1)].guest_visit(self.Strike_Counter)
        print "3 strikes! Game Over!"

#save game
    def save_game(self):
        try:
            game_hotel.write_to_file()
        except:
            print "No save file."

#save information to save.txt
    def write_to_file(self):
        print "Writing to save.txt..."
        print "Player name: " + self.game_hotel.player_name
        print "Difficulty: " + self.game_hotel.difficulty
        self.save_file = open("save.txt", "w")
        sentence = str(self.game_hotel.difficulty) + "\n"
        sentence += str(self.game_hotel.player_name) + "\n"
        sentence += str(self.game_hotel.Score) + "\n"
        sentence += str(self.Strike_Counter) + "\n"
        self.save_file.write(sentence)
