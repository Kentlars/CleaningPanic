import RoomFile

class Hotel(object):

    Score = 0
    #rooms
    rooms = []

#default constructor
    @classmethod
    def from_start(cls, difficulty):
        obj = cls()
        obj.difficulty = difficulty
        obj.player_name = ""
        obj.setup_player()
        #obj.write_to_file()
        count = 0
        while count < 4:
            obj.rooms.append(RoomFile.Room(str(count +1)))
            count += 1
        return obj

#When a player choses 3 as startup-argument, it uses a constructor to load in
#existing values from "save.txt"
    @classmethod
    def from_everything(cls):
        obj = cls()
        file = open("save.txt")
        lines = file.read().splitlines()
        obj.difficulty = lines[0]
        obj.player_name = lines[1]
        obj.Score = lines[2]
        return obj

    def setup_player(self):
        self.player_name = raw_input('What is your name? ')
        print "Hello", self.player_name, "!"
