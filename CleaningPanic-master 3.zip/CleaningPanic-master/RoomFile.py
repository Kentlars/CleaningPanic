#to keep track on rooms
from random import randint
from random import getrandbits

class Room(object):

    is_cleaned = None
    has_guest = None
    room_number = 0

    def __init__(self, number):
        self.is_cleaned = True
        self.has_guest = False
        self.room_number = number

#Adds a strike point if the room is dirty when the guest is visiting it
    def guest_visit(self, strike_point):
        print "Calling room " , self.room_number
        self.guest_leave()
        if self.is_cleaned == False:
            print "Room %s is dirty! Increasing strike point by 1!" % self.room_number
            strike_point += 1
            self.is_cleaned = True
            print "Room %s is now clean" % self.room_number
        return strike_point

#makes the room dirty after guest leaves the room
    def guest_leave(self):
        print str(getrandbits(1))
        if bool(getrandbits(1)) == True:
            self.is_cleaned = False
